<?php

namespace ContainerPl2WueL;
include_once \dirname(__DIR__, 4).''.\DIRECTORY_SEPARATOR.'vendor'.\DIRECTORY_SEPARATOR.'doctrine'.\DIRECTORY_SEPARATOR.'persistence'.\DIRECTORY_SEPARATOR.'lib'.\DIRECTORY_SEPARATOR.'Doctrine'.\DIRECTORY_SEPARATOR.'Persistence'.\DIRECTORY_SEPARATOR.'ObjectManager.php';
include_once \dirname(__DIR__, 4).''.\DIRECTORY_SEPARATOR.'vendor'.\DIRECTORY_SEPARATOR.'doctrine'.\DIRECTORY_SEPARATOR.'orm'.\DIRECTORY_SEPARATOR.'lib'.\DIRECTORY_SEPARATOR.'Doctrine'.\DIRECTORY_SEPARATOR.'ORM'.\DIRECTORY_SEPARATOR.'EntityManagerInterface.php';
include_once \dirname(__DIR__, 4).''.\DIRECTORY_SEPARATOR.'vendor'.\DIRECTORY_SEPARATOR.'doctrine'.\DIRECTORY_SEPARATOR.'orm'.\DIRECTORY_SEPARATOR.'lib'.\DIRECTORY_SEPARATOR.'Doctrine'.\DIRECTORY_SEPARATOR.'ORM'.\DIRECTORY_SEPARATOR.'EntityManager.php';

class EntityManager_9a5be93 extends \Doctrine\ORM\EntityManager implements \ProxyManager\Proxy\VirtualProxyInterface
{
    /**
     * @var \Doctrine\ORM\EntityManager|null wrapped object, if the proxy is initialized
     */
    private $valueHolderf2749 = null;

    /**
     * @var \Closure|null initializer responsible for generating the wrapped object
     */
    private $initializer081a7 = null;

    /**
     * @var bool[] map of public properties of the parent class
     */
    private static $publicProperties734ed = [
        
    ];

    public function getConnection()
    {
        $this->initializer081a7 && ($this->initializer081a7->__invoke($valueHolderf2749, $this, 'getConnection', array(), $this->initializer081a7) || 1) && $this->valueHolderf2749 = $valueHolderf2749;

        return $this->valueHolderf2749->getConnection();
    }

    public function getMetadataFactory()
    {
        $this->initializer081a7 && ($this->initializer081a7->__invoke($valueHolderf2749, $this, 'getMetadataFactory', array(), $this->initializer081a7) || 1) && $this->valueHolderf2749 = $valueHolderf2749;

        return $this->valueHolderf2749->getMetadataFactory();
    }

    public function getExpressionBuilder()
    {
        $this->initializer081a7 && ($this->initializer081a7->__invoke($valueHolderf2749, $this, 'getExpressionBuilder', array(), $this->initializer081a7) || 1) && $this->valueHolderf2749 = $valueHolderf2749;

        return $this->valueHolderf2749->getExpressionBuilder();
    }

    public function beginTransaction()
    {
        $this->initializer081a7 && ($this->initializer081a7->__invoke($valueHolderf2749, $this, 'beginTransaction', array(), $this->initializer081a7) || 1) && $this->valueHolderf2749 = $valueHolderf2749;

        return $this->valueHolderf2749->beginTransaction();
    }

    public function getCache()
    {
        $this->initializer081a7 && ($this->initializer081a7->__invoke($valueHolderf2749, $this, 'getCache', array(), $this->initializer081a7) || 1) && $this->valueHolderf2749 = $valueHolderf2749;

        return $this->valueHolderf2749->getCache();
    }

    public function transactional($func)
    {
        $this->initializer081a7 && ($this->initializer081a7->__invoke($valueHolderf2749, $this, 'transactional', array('func' => $func), $this->initializer081a7) || 1) && $this->valueHolderf2749 = $valueHolderf2749;

        return $this->valueHolderf2749->transactional($func);
    }

    public function commit()
    {
        $this->initializer081a7 && ($this->initializer081a7->__invoke($valueHolderf2749, $this, 'commit', array(), $this->initializer081a7) || 1) && $this->valueHolderf2749 = $valueHolderf2749;

        return $this->valueHolderf2749->commit();
    }

    public function rollback()
    {
        $this->initializer081a7 && ($this->initializer081a7->__invoke($valueHolderf2749, $this, 'rollback', array(), $this->initializer081a7) || 1) && $this->valueHolderf2749 = $valueHolderf2749;

        return $this->valueHolderf2749->rollback();
    }

    public function getClassMetadata($className)
    {
        $this->initializer081a7 && ($this->initializer081a7->__invoke($valueHolderf2749, $this, 'getClassMetadata', array('className' => $className), $this->initializer081a7) || 1) && $this->valueHolderf2749 = $valueHolderf2749;

        return $this->valueHolderf2749->getClassMetadata($className);
    }

    public function createQuery($dql = '')
    {
        $this->initializer081a7 && ($this->initializer081a7->__invoke($valueHolderf2749, $this, 'createQuery', array('dql' => $dql), $this->initializer081a7) || 1) && $this->valueHolderf2749 = $valueHolderf2749;

        return $this->valueHolderf2749->createQuery($dql);
    }

    public function createNamedQuery($name)
    {
        $this->initializer081a7 && ($this->initializer081a7->__invoke($valueHolderf2749, $this, 'createNamedQuery', array('name' => $name), $this->initializer081a7) || 1) && $this->valueHolderf2749 = $valueHolderf2749;

        return $this->valueHolderf2749->createNamedQuery($name);
    }

    public function createNativeQuery($sql, \Doctrine\ORM\Query\ResultSetMapping $rsm)
    {
        $this->initializer081a7 && ($this->initializer081a7->__invoke($valueHolderf2749, $this, 'createNativeQuery', array('sql' => $sql, 'rsm' => $rsm), $this->initializer081a7) || 1) && $this->valueHolderf2749 = $valueHolderf2749;

        return $this->valueHolderf2749->createNativeQuery($sql, $rsm);
    }

    public function createNamedNativeQuery($name)
    {
        $this->initializer081a7 && ($this->initializer081a7->__invoke($valueHolderf2749, $this, 'createNamedNativeQuery', array('name' => $name), $this->initializer081a7) || 1) && $this->valueHolderf2749 = $valueHolderf2749;

        return $this->valueHolderf2749->createNamedNativeQuery($name);
    }

    public function createQueryBuilder()
    {
        $this->initializer081a7 && ($this->initializer081a7->__invoke($valueHolderf2749, $this, 'createQueryBuilder', array(), $this->initializer081a7) || 1) && $this->valueHolderf2749 = $valueHolderf2749;

        return $this->valueHolderf2749->createQueryBuilder();
    }

    public function flush($entity = null)
    {
        $this->initializer081a7 && ($this->initializer081a7->__invoke($valueHolderf2749, $this, 'flush', array('entity' => $entity), $this->initializer081a7) || 1) && $this->valueHolderf2749 = $valueHolderf2749;

        return $this->valueHolderf2749->flush($entity);
    }

    public function find($className, $id, $lockMode = null, $lockVersion = null)
    {
        $this->initializer081a7 && ($this->initializer081a7->__invoke($valueHolderf2749, $this, 'find', array('className' => $className, 'id' => $id, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializer081a7) || 1) && $this->valueHolderf2749 = $valueHolderf2749;

        return $this->valueHolderf2749->find($className, $id, $lockMode, $lockVersion);
    }

    public function getReference($entityName, $id)
    {
        $this->initializer081a7 && ($this->initializer081a7->__invoke($valueHolderf2749, $this, 'getReference', array('entityName' => $entityName, 'id' => $id), $this->initializer081a7) || 1) && $this->valueHolderf2749 = $valueHolderf2749;

        return $this->valueHolderf2749->getReference($entityName, $id);
    }

    public function getPartialReference($entityName, $identifier)
    {
        $this->initializer081a7 && ($this->initializer081a7->__invoke($valueHolderf2749, $this, 'getPartialReference', array('entityName' => $entityName, 'identifier' => $identifier), $this->initializer081a7) || 1) && $this->valueHolderf2749 = $valueHolderf2749;

        return $this->valueHolderf2749->getPartialReference($entityName, $identifier);
    }

    public function clear($entityName = null)
    {
        $this->initializer081a7 && ($this->initializer081a7->__invoke($valueHolderf2749, $this, 'clear', array('entityName' => $entityName), $this->initializer081a7) || 1) && $this->valueHolderf2749 = $valueHolderf2749;

        return $this->valueHolderf2749->clear($entityName);
    }

    public function close()
    {
        $this->initializer081a7 && ($this->initializer081a7->__invoke($valueHolderf2749, $this, 'close', array(), $this->initializer081a7) || 1) && $this->valueHolderf2749 = $valueHolderf2749;

        return $this->valueHolderf2749->close();
    }

    public function persist($entity)
    {
        $this->initializer081a7 && ($this->initializer081a7->__invoke($valueHolderf2749, $this, 'persist', array('entity' => $entity), $this->initializer081a7) || 1) && $this->valueHolderf2749 = $valueHolderf2749;

        return $this->valueHolderf2749->persist($entity);
    }

    public function remove($entity)
    {
        $this->initializer081a7 && ($this->initializer081a7->__invoke($valueHolderf2749, $this, 'remove', array('entity' => $entity), $this->initializer081a7) || 1) && $this->valueHolderf2749 = $valueHolderf2749;

        return $this->valueHolderf2749->remove($entity);
    }

    public function refresh($entity)
    {
        $this->initializer081a7 && ($this->initializer081a7->__invoke($valueHolderf2749, $this, 'refresh', array('entity' => $entity), $this->initializer081a7) || 1) && $this->valueHolderf2749 = $valueHolderf2749;

        return $this->valueHolderf2749->refresh($entity);
    }

    public function detach($entity)
    {
        $this->initializer081a7 && ($this->initializer081a7->__invoke($valueHolderf2749, $this, 'detach', array('entity' => $entity), $this->initializer081a7) || 1) && $this->valueHolderf2749 = $valueHolderf2749;

        return $this->valueHolderf2749->detach($entity);
    }

    public function merge($entity)
    {
        $this->initializer081a7 && ($this->initializer081a7->__invoke($valueHolderf2749, $this, 'merge', array('entity' => $entity), $this->initializer081a7) || 1) && $this->valueHolderf2749 = $valueHolderf2749;

        return $this->valueHolderf2749->merge($entity);
    }

    public function copy($entity, $deep = false)
    {
        $this->initializer081a7 && ($this->initializer081a7->__invoke($valueHolderf2749, $this, 'copy', array('entity' => $entity, 'deep' => $deep), $this->initializer081a7) || 1) && $this->valueHolderf2749 = $valueHolderf2749;

        return $this->valueHolderf2749->copy($entity, $deep);
    }

    public function lock($entity, $lockMode, $lockVersion = null)
    {
        $this->initializer081a7 && ($this->initializer081a7->__invoke($valueHolderf2749, $this, 'lock', array('entity' => $entity, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializer081a7) || 1) && $this->valueHolderf2749 = $valueHolderf2749;

        return $this->valueHolderf2749->lock($entity, $lockMode, $lockVersion);
    }

    public function getRepository($entityName)
    {
        $this->initializer081a7 && ($this->initializer081a7->__invoke($valueHolderf2749, $this, 'getRepository', array('entityName' => $entityName), $this->initializer081a7) || 1) && $this->valueHolderf2749 = $valueHolderf2749;

        return $this->valueHolderf2749->getRepository($entityName);
    }

    public function contains($entity)
    {
        $this->initializer081a7 && ($this->initializer081a7->__invoke($valueHolderf2749, $this, 'contains', array('entity' => $entity), $this->initializer081a7) || 1) && $this->valueHolderf2749 = $valueHolderf2749;

        return $this->valueHolderf2749->contains($entity);
    }

    public function getEventManager()
    {
        $this->initializer081a7 && ($this->initializer081a7->__invoke($valueHolderf2749, $this, 'getEventManager', array(), $this->initializer081a7) || 1) && $this->valueHolderf2749 = $valueHolderf2749;

        return $this->valueHolderf2749->getEventManager();
    }

    public function getConfiguration()
    {
        $this->initializer081a7 && ($this->initializer081a7->__invoke($valueHolderf2749, $this, 'getConfiguration', array(), $this->initializer081a7) || 1) && $this->valueHolderf2749 = $valueHolderf2749;

        return $this->valueHolderf2749->getConfiguration();
    }

    public function isOpen()
    {
        $this->initializer081a7 && ($this->initializer081a7->__invoke($valueHolderf2749, $this, 'isOpen', array(), $this->initializer081a7) || 1) && $this->valueHolderf2749 = $valueHolderf2749;

        return $this->valueHolderf2749->isOpen();
    }

    public function getUnitOfWork()
    {
        $this->initializer081a7 && ($this->initializer081a7->__invoke($valueHolderf2749, $this, 'getUnitOfWork', array(), $this->initializer081a7) || 1) && $this->valueHolderf2749 = $valueHolderf2749;

        return $this->valueHolderf2749->getUnitOfWork();
    }

    public function getHydrator($hydrationMode)
    {
        $this->initializer081a7 && ($this->initializer081a7->__invoke($valueHolderf2749, $this, 'getHydrator', array('hydrationMode' => $hydrationMode), $this->initializer081a7) || 1) && $this->valueHolderf2749 = $valueHolderf2749;

        return $this->valueHolderf2749->getHydrator($hydrationMode);
    }

    public function newHydrator($hydrationMode)
    {
        $this->initializer081a7 && ($this->initializer081a7->__invoke($valueHolderf2749, $this, 'newHydrator', array('hydrationMode' => $hydrationMode), $this->initializer081a7) || 1) && $this->valueHolderf2749 = $valueHolderf2749;

        return $this->valueHolderf2749->newHydrator($hydrationMode);
    }

    public function getProxyFactory()
    {
        $this->initializer081a7 && ($this->initializer081a7->__invoke($valueHolderf2749, $this, 'getProxyFactory', array(), $this->initializer081a7) || 1) && $this->valueHolderf2749 = $valueHolderf2749;

        return $this->valueHolderf2749->getProxyFactory();
    }

    public function initializeObject($obj)
    {
        $this->initializer081a7 && ($this->initializer081a7->__invoke($valueHolderf2749, $this, 'initializeObject', array('obj' => $obj), $this->initializer081a7) || 1) && $this->valueHolderf2749 = $valueHolderf2749;

        return $this->valueHolderf2749->initializeObject($obj);
    }

    public function getFilters()
    {
        $this->initializer081a7 && ($this->initializer081a7->__invoke($valueHolderf2749, $this, 'getFilters', array(), $this->initializer081a7) || 1) && $this->valueHolderf2749 = $valueHolderf2749;

        return $this->valueHolderf2749->getFilters();
    }

    public function isFiltersStateClean()
    {
        $this->initializer081a7 && ($this->initializer081a7->__invoke($valueHolderf2749, $this, 'isFiltersStateClean', array(), $this->initializer081a7) || 1) && $this->valueHolderf2749 = $valueHolderf2749;

        return $this->valueHolderf2749->isFiltersStateClean();
    }

    public function hasFilters()
    {
        $this->initializer081a7 && ($this->initializer081a7->__invoke($valueHolderf2749, $this, 'hasFilters', array(), $this->initializer081a7) || 1) && $this->valueHolderf2749 = $valueHolderf2749;

        return $this->valueHolderf2749->hasFilters();
    }

    /**
     * Constructor for lazy initialization
     *
     * @param \Closure|null $initializer
     */
    public static function staticProxyConstructor($initializer)
    {
        static $reflection;

        $reflection = $reflection ?? new \ReflectionClass(__CLASS__);
        $instance   = $reflection->newInstanceWithoutConstructor();

        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $instance, 'Doctrine\\ORM\\EntityManager')->__invoke($instance);

        $instance->initializer081a7 = $initializer;

        return $instance;
    }

    protected function __construct(\Doctrine\DBAL\Connection $conn, \Doctrine\ORM\Configuration $config, \Doctrine\Common\EventManager $eventManager)
    {
        static $reflection;

        if (! $this->valueHolderf2749) {
            $reflection = $reflection ?? new \ReflectionClass('Doctrine\\ORM\\EntityManager');
            $this->valueHolderf2749 = $reflection->newInstanceWithoutConstructor();
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);

        }

        $this->valueHolderf2749->__construct($conn, $config, $eventManager);
    }

    public function & __get($name)
    {
        $this->initializer081a7 && ($this->initializer081a7->__invoke($valueHolderf2749, $this, '__get', ['name' => $name], $this->initializer081a7) || 1) && $this->valueHolderf2749 = $valueHolderf2749;

        if (isset(self::$publicProperties734ed[$name])) {
            return $this->valueHolderf2749->$name;
        }

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolderf2749;

            $backtrace = debug_backtrace(false, 1);
            trigger_error(
                sprintf(
                    'Undefined property: %s::$%s in %s on line %s',
                    $realInstanceReflection->getName(),
                    $name,
                    $backtrace[0]['file'],
                    $backtrace[0]['line']
                ),
                \E_USER_NOTICE
            );
            return $targetObject->$name;
        }

        $targetObject = $this->valueHolderf2749;
        $accessor = function & () use ($targetObject, $name) {
            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __set($name, $value)
    {
        $this->initializer081a7 && ($this->initializer081a7->__invoke($valueHolderf2749, $this, '__set', array('name' => $name, 'value' => $value), $this->initializer081a7) || 1) && $this->valueHolderf2749 = $valueHolderf2749;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolderf2749;

            $targetObject->$name = $value;

            return $targetObject->$name;
        }

        $targetObject = $this->valueHolderf2749;
        $accessor = function & () use ($targetObject, $name, $value) {
            $targetObject->$name = $value;

            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __isset($name)
    {
        $this->initializer081a7 && ($this->initializer081a7->__invoke($valueHolderf2749, $this, '__isset', array('name' => $name), $this->initializer081a7) || 1) && $this->valueHolderf2749 = $valueHolderf2749;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolderf2749;

            return isset($targetObject->$name);
        }

        $targetObject = $this->valueHolderf2749;
        $accessor = function () use ($targetObject, $name) {
            return isset($targetObject->$name);
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = $accessor();

        return $returnValue;
    }

    public function __unset($name)
    {
        $this->initializer081a7 && ($this->initializer081a7->__invoke($valueHolderf2749, $this, '__unset', array('name' => $name), $this->initializer081a7) || 1) && $this->valueHolderf2749 = $valueHolderf2749;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolderf2749;

            unset($targetObject->$name);

            return;
        }

        $targetObject = $this->valueHolderf2749;
        $accessor = function () use ($targetObject, $name) {
            unset($targetObject->$name);

            return;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $accessor();
    }

    public function __clone()
    {
        $this->initializer081a7 && ($this->initializer081a7->__invoke($valueHolderf2749, $this, '__clone', array(), $this->initializer081a7) || 1) && $this->valueHolderf2749 = $valueHolderf2749;

        $this->valueHolderf2749 = clone $this->valueHolderf2749;
    }

    public function __sleep()
    {
        $this->initializer081a7 && ($this->initializer081a7->__invoke($valueHolderf2749, $this, '__sleep', array(), $this->initializer081a7) || 1) && $this->valueHolderf2749 = $valueHolderf2749;

        return array('valueHolderf2749');
    }

    public function __wakeup()
    {
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);
    }

    public function setProxyInitializer(\Closure $initializer = null) : void
    {
        $this->initializer081a7 = $initializer;
    }

    public function getProxyInitializer() : ?\Closure
    {
        return $this->initializer081a7;
    }

    public function initializeProxy() : bool
    {
        return $this->initializer081a7 && ($this->initializer081a7->__invoke($valueHolderf2749, $this, 'initializeProxy', array(), $this->initializer081a7) || 1) && $this->valueHolderf2749 = $valueHolderf2749;
    }

    public function isProxyInitialized() : bool
    {
        return null !== $this->valueHolderf2749;
    }

    public function getWrappedValueHolderValue()
    {
        return $this->valueHolderf2749;
    }
}

if (!\class_exists('EntityManager_9a5be93', false)) {
    \class_alias(__NAMESPACE__.'\\EntityManager_9a5be93', 'EntityManager_9a5be93', false);
}
