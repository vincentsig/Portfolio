<?php

namespace App\Tests;

use App\Entity\Skill;
use App\Tests\Framework\WebTestCase;

class SkillControllerTest extends WebTestCase
{
}
